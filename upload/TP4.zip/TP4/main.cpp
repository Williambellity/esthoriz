///////////////////////////////////////////////////////////////////////////////
//
//	main.cpp
//
///////////////////////////////////////////////////////////////////////////////
#include <systemc.h>
#include "processor.h"
#include "CoProcessor.h"
#include "DataRAM.h"
#include "InstRAM.h"
#include "Console.h"
#include "wrapper_console_TLM.h"
#include "wrapper_processor_TLM.h"
#include "wrapper_coProcessor_TLM.h"
#include "SimpleBusLT.h"
#include "busLT_standalone_definition.h"

#define RAMSIZE 0x400

using namespace std;

// Variable gloable
bool m_bError = false;

///////////////////////////////////////////////////////////////////////////////
//
//	Entr�e principale de l'application
//
///////////////////////////////////////////////////////////////////////////////
int sc_main(int arg_count, char **arg_value)
{
	// Variable
	time_t simulation_time_begin = 0;
	time_t simulation_time_end = 0;
	int sim_units = 2; //SC_NS 
	
	// Horloge
	sc_clock clk( "SysClock", 40, SC_NS, 0.5 );

	// Cr�ation des objets
	CoProcessor coproc("coproc"); // coproc
	wrapper_coProcessor_TLM coproc_wrapper("coproc_wrapper", ADRESSE_COPROCESSOR_DEBUT, ADRESSE_COPROCESSOR_FIN);
	SimpleBusLT<1, 2> bus_tlm("bus_tlm"); // bus
	Console console("console"); // console
	wrapper_console_TLM console_wrapper("console_wrapper", ADRESSE_CONSOLE_DEBUT, ADRESSE_CONSOLE_FIN);
	processor proc("proc", RAMSIZE,RAMSIZE,false); // proc
	wrapper_processor_TLM proc_wrapper("proc_wrapper");
	InstRAM instruction("instruction", "app.elf", RAMSIZE, m_bError);
	DataRAM dataRam("RAM", "chiffre.hex", RAMSIZE, m_bError);
	
	// Branchement d'horloge
	coproc.ClockPort(clk);
	coproc_wrapper.ClockPort(clk);
	console.ClockPort(clk);
	console_wrapper.ClockPort(clk);
	proc_wrapper.ClockPort(clk);
	proc.ClockPort(clk);
	
	// Branchement
	proc.InstPort(instruction);
	proc.DataPort(dataRam);
	
	// Creation des signaux Processeur
	sc_signal<unsigned int>	Proc_Data_OutPort;
	sc_signal<unsigned int>	Proc_Data_InPort;
	sc_signal<unsigned int>	Proc_Address;
	sc_signal<bool>			Proc_Enable;
	sc_signal<bool>			Proc_Ready;
	sc_signal<bool>			Proc_RW;
	
	// Branchement des signaux Processor <> WrapperProcessor
	proc.Processor_Data_OutPort(Proc_Data_OutPort);
	proc.Processor_Data_InPort(Proc_Data_InPort);
	proc.Processor_Address_OutPort(Proc_Address);
	proc.Processor_Enable_OutPort(Proc_Enable);
	proc.Processor_Ready_InPort(Proc_Ready);
	proc.Processor_RW_OutPort(Proc_RW);
	proc_wrapper.Wrapper_Data_OutPort(Proc_Data_InPort);
	proc_wrapper.Wrapper_Data_InPort(Proc_Data_OutPort);
	proc_wrapper.Wrapper_Address_InPort(Proc_Address);
	proc_wrapper.Wrapper_Enable_InPort(Proc_Enable);
	proc_wrapper.Wrapper_Ready_OutPort(Proc_Ready);
	proc_wrapper.Wrapper_RW_InPort(Proc_RW);
	
	// Signaux CoProcessor
	sc_signal<unsigned int> CoProc_Data_OutPort;
	sc_signal<unsigned int> CoProc_Data_InPort;
	sc_signal<bool> 		CoProc_Enable;
	sc_signal<bool> 		CoProc_Ready;
	sc_signal<bool> 		CoProc_RW;
	
	// Branchement des signaux CoProcessor <> WrapperCoProcessor
	coproc.CoProcessor_Data_OutPort(CoProc_Data_OutPort);
	coproc.CoProcessor_Data_InPort(CoProc_Data_InPort);
	coproc.CoProcessor_Enable_InPort(CoProc_Enable);
	coproc.CoProcessor_Ready_OutPort(CoProc_Ready);
	coproc.CoProcessor_RW_OutPort(CoProc_RW);
	coproc_wrapper.Wrapper_Data_OutPort(CoProc_Data_OutPort);
	coproc_wrapper.Wrapper_Data_InPort(CoProc_Data_InPort);
	coproc_wrapper.Wrapper_Enable_OutPort(CoProc_Enable);
	coproc_wrapper.Wrapper_Ready_InPort(CoProc_Ready);
	coproc_wrapper.Wrapper_RW_InPort(CoProc_RW);
	
	// signaux Console
	sc_signal<unsigned int> Console_Data;
	sc_signal<bool>			Console_Enable;	
	sc_signal<bool>			Console_Ready;
	
	// branchement Console <> WrapperConsole
	console.Console_Data_InPort(Console_Data);
	console.Console_Enable_InPort(Console_Enable);
	console.Console_Ready_OutPort(Console_Ready);
	console_wrapper.Wrapper_Data_OutPort(Console_Data);
	console_wrapper.Wrapper_Enable_OutPort(Console_Enable);
	console_wrapper.Wrapper_Ready_InPort(Console_Ready);
	
	// Bind initiator socket to target socket
	proc_wrapper.socket.bind(bus_tlm.target_socket[0]);
	bus_tlm.initiator_socket[0].bind(coproc_wrapper.socket);
	bus_tlm.initiator_socket[1].bind(console_wrapper.socket);
	
	// D�marrage de l'application
	if (!m_bError)
	{
		cout << "D�marrage de la simulation." << endl;
		time( &simulation_time_begin );
		sc_start( -1, sc_core::sc_time_unit(sim_units) );
		time( &simulation_time_end );

		cout << endl << "Simulation s'est termin�e � " << sc_time_stamp() << " ns";
		cout << endl << "Dur�e de la simulation: " << (unsigned long)(simulation_time_end - simulation_time_begin) << " secondes." << endl << endl;
	}
	// Fin du programme
	return 0;
}
