///////////////////////////////////////////////////////////////////////////////
//
//	SimpleBusLT.h
//
///////////////////////////////////////////////////////////////////////////////

#ifndef __SIMPLEBUSLT_H__
#define __SIMPLEBUSLT_H__

#include "busLT_standalone_definition.h"
#include <tlm_utils/simple_target_socket.h>
#include <tlm_utils/simple_initiator_socket.h>
#include <systemc.h>
#include <stdio.h>

template <int NR_OF_INITIATORS, int NR_OF_TARGETS>

//Class SimpleBusLT
class SimpleBusLT : public sc_core::sc_module
{
	typedef tlm_utils::simple_target_socket_tagged<SimpleBusLT>		target_socket_type;
	typedef tlm_utils::simple_initiator_socket_tagged<SimpleBusLT>	initiator_socket_type;
	
	public:
		target_socket_type target_socket[NR_OF_INITIATORS];
		initiator_socket_type initiator_socket[NR_OF_TARGETS];

		SC_HAS_PROCESS(SimpleBusLT);	
		//	Constructeur
		SimpleBusLT(sc_core::sc_module_name name) : sc_module(name)
		{
			target_socket[0].register_b_transport(this, &SimpleBusLT::initiatorBTransport, 0);
		}
		
		//	Decode
		// Pour savoir si le paquet est destine a la console ou au CoProc
		unsigned int decode(const sc_dt::uint64& address)
		{
			// Console
			if (address >= ADRESSE_CONSOLE_DEBUT && address <= ADRESSE_CONSOLE_FIN) {
				return 1;
			}
			
			// CoProc
			if (address >= ADRESSE_COPROCESSOR_DEBUT && address <= ADRESSE_COPROCESSOR_FIN) {
				return 2;
			}
			
			return 0;
		}

		//	Interface method(LT protocol)
		//	Forward each call to the target/initiator
		void initiatorBTransport(int SocketId, transaction_type& trans, sc_time& t)
		{
			initiator_socket_type* socket;
			
			// Forward
			switch (decode(trans.get_address())) {
				// Console
				case 1:
					socket = &initiator_socket[1]; // Blocking transport call
					break;
				
				// CoProc
				case 2:
					socket = &initiator_socket[0]; // Blocking transport call
					break;
			}
			
			(*socket)->b_transport(trans, t);
		}
};

#endif
