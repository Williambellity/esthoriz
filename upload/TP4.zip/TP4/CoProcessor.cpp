///////////////////////////////////////////////////////////////////////////////
//
//	CoProcessor.cpp
//
///////////////////////////////////////////////////////////////////////////////

#define COMPTE_1 0
#define RECOIT_CHARS_1 1
#define COMPTE_2 2
#define RECOIT_CHARS_2 3

#include "CoProcessor.h"
#include <iostream>
#include <vector>

using namespace std;


///////////////////////////////////////////////////////////////////////////////
//
//	Constructeur
//
///////////////////////////////////////////////////////////////////////////////
CoProcessor::CoProcessor( sc_module_name zName )
: sc_module(zName)
{
	// Vous ne devez pas changer ceci
	SC_THREAD(thread);
		sensitive << ClockPort.pos();
	
	reg[2].write(0);
}


///////////////////////////////////////////////////////////////////////////////
//
//	Destructeur
//
///////////////////////////////////////////////////////////////////////////////
CoProcessor::~CoProcessor()
{
}


///////////////////////////////////////////////////////////////////////////////
//
//	thread
//
///////////////////////////////////////////////////////////////////////////////
void CoProcessor::thread(void)
{
	char *string1, *string2;
	int i = 0;
	unsigned int addr;
	unsigned long data;
	
	// Boucle infinie
	while (true) {
		// On dit au wrapper qu'on est pr�t pour la suite
		CoProcessor_Ready_OutPort.write(true);
		
		// Attente de la donn�ee
		wait(CoProcessor_Enable_InPort.default_event());
		
		// On dit au wrapper qu'on est pr�t pour la suite
		CoProcessor_Ready_OutPort.write(false);
		
		// R�cup�ration de l'adresse
		addr = CoProcessor_Data_InPort.read();
		
		cout << "CoProc : requete lecture a l'adresse " << addr << endl;
		
		// On re�oit des donn�ees du bus
		if (CoProcessor_RW_OutPort.read()) {
			wait(1);
			
			// On dit au wrapper qu'on est pr�t pour la suite
			CoProcessor_Ready_OutPort.write(true);
			
			cout << "CoProc : attente donnee " << endl;
			
			// Attente de la donn�e
			wait(CoProcessor_Enable_InPort.default_event());
			
			// Fin de la transaction
			CoProcessor_Ready_OutPort.write(false);
			
			// R�cup�ration des donn�es
			data = CoProcessor_Data_InPort.read();
			
			cout << "CoProc : donnee recue = " << data << endl;
		}
		
		switch (addr) {
			// R�ception quantit� de caract�re dans une cha�ne
			case 0x2000:
				cout << "CoProc : reception taille de chaine" << endl;
				
				// Enregistrement de la longueur de la cha�ne
				if (i == 0) {
					reg[0].write(data);
					// Initialisation du tableau de chars 1
					string1 = (char*) malloc(reg[0].read() * sizeof(char));
				} else {
					reg[1].write(data);
					// Initialisation du tableau de chars 1
					string2 = (char*) malloc(reg[1].read() * sizeof(char));
				}
				break;
			
			// R�ception caract�res d'une cha�ne
			case 0x2001:
				cout << "CoProc : reception d'une lettre" << endl;
				
				// R�cup�re la donn�e
				if (i <= reg[0].read()) {
					cout << "CoProc : i string1" << endl;
					string1[i] = data;
				} else {
					cout << "CoProc : i string2 " << i-reg[0].read() << endl;
					string2[i-reg[0].read()] = data;
				}
				
				i++;
				
				if (reg[1].read() != 0 && i == reg[0].read() + reg[1].read()) {
					// On a fini de lire
					reg[2].write(1);
					
					// Recherche sous saquence
					recherchePlusLongueSousSequence(reg[0].read(), string1, reg[1].read(), string2);
					reg[2].write(2);
					
					i = 0;
				}
				break;
			
			// Lecture �tat coprocesseur
			case 0x2002:
				cout << "CoProc : lecture etat registre" << endl;
				
				CoProcessor_Data_OutPort.write(reg[2].read());
				
				wait(1);
				CoProcessor_Ready_OutPort.write(true);
				break;
			
			// Lecture taille de plus longue sous s�quence
			case 0x2003:
				cout << "taille sous chaine = " << sous_seq.size() << endl;
				
				// Ecriture sur le bus de la taille de la chaine
				CoProcessor_Data_OutPort.write(sous_seq.size());
				
				wait(1);
				CoProcessor_Ready_OutPort.write(true);
				break;
			
			// Lecture caracteres de la plus longue sous s�quence
			case 0x2004:
				cout << "CoProc : envoi caractere seq_max" << endl;
				
				// Ecriture sur le bus de la taille de la chaine
				CoProcessor_Data_OutPort.write(sous_seq[i]);
				
				wait(1);
				CoProcessor_Ready_OutPort.write(true);
				
				if ((unsigned int) i == 2) {
					sc_stop();
				}
				
				i++;
				break;
		}
		
		wait(1);
	}
}

///////////////////////////////////////////////////////////////////////////////
// 	Computing
//  Longest common substring method
///////////////////////////////////////////////////////////////////////////////
void CoProcessor::recherchePlusLongueSousSequence(int L1, char* A, int L2, char* B) {
	int max = 0, count = 0;
	for (int i = 0; i < L1; i++) {
		count = 0;
		for (int j = 0; j < L2; j++) {
			if (A[i+count] == B[j] && i+count < L1) {
				count++;
			} else {
				if (count > max) {
					max = count;
					// Recopiage de la sous s�quence
					sous_seq.clear();
					for (int x = 0; x < count; x++) {
						sous_seq.push_back(A[i+x]);
					}
				}
				count = 0;
			}
		}
	}
}
