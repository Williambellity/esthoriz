///////////////////////////////////////////////////////////////////////////////
//
//	wrapper_coProcessor_TLM.cpp
//
///////////////////////////////////////////////////////////////////////////////
#include "wrapper_coProcessor_TLM.h"

///////////////////////////////////////////////////////////////////////////////
//
//	Constructeur
//
///////////////////////////////////////////////////////////////////////////////
wrapper_coProcessor_TLM::wrapper_coProcessor_TLM(sc_module_name zName, unsigned long ulStartAdress, unsigned long ulEndAdress)
: sc_module(zName)
{
	//Assigne les variables
	m_ulStartAdress = ulStartAdress;
	m_ulEndAdress = ulEndAdress;
	socket.register_b_transport(this, &wrapper_coProcessor_TLM::b_transport);
}


///////////////////////////////////////////////////////////////////////////////
//
//	Destructeur
//
///////////////////////////////////////////////////////////////////////////////
wrapper_coProcessor_TLM::~wrapper_coProcessor_TLM()
{
}

///////////////////////////////////////////////////////////////////////////////
//
//	b_transport : r�pond aux requ�tes envoy�es par le initiatot
//
///////////////////////////////////////////////////////////////////////////////
void wrapper_coProcessor_TLM::b_transport( transaction_type& trans, sc_time& delay )
{
	command_type cmd = trans.get_command();
	sc_dt::uint64    add = trans.get_address();
	unsigned char*   ptr = trans.get_data_ptr();
	unsigned int     len = trans.get_data_length();
	unsigned char*   byt = trans.get_byte_enable_ptr();
	unsigned int     wid = trans.get_streaming_width();
	sc_time dly = sc_time(30, SC_NS);

	
	
	//V�rification 
	if (byt != 0 || wid < len)
	  SC_REPORT_ERROR("TLM-2", "Target does not support given generic payload transaction");
	
	// On v�rifie si la requ�te est de lecture ou �criture
	if ( cmd == tlm::TLM_READ_COMMAND ){
		busLT_slave_read(add, ptr, len);
	}
	else if ( cmd == tlm::TLM_WRITE_COMMAND ){
		busLT_slave_write(add, ptr, len);
	}
	
	//Temps d'attente
	delay += dly;
	
	// Aquittement
	trans.set_response_status( tlm::TLM_OK_RESPONSE );
	
}
///////////////////////////////////////////////////////////////////////////////
//
//	busLT_slave_read
//  Le bus veut lire l'�tat du CoProc
//
///////////////////////////////////////////////////////////////////////////////
void wrapper_coProcessor_TLM::busLT_slave_read(sc_dt::uint64 add, unsigned char* ptrData, unsigned int len)
{
	unsigned int data;
	
	cout << "Wrapper_CoProc : demande d'envoi d'une donn�e" << endl;
	
	// On demande au coproc d'�tre en �criture
	Wrapper_RW_InPort.write(false);
	
	// On envoie l'adresse au CoProc
	Wrapper_Data_InPort.write(add);
	
	// On indique que la donn�e est pr�te
	Wrapper_Enable_OutPort.write(true);
	
	cout << "Wrapper_CoProc : avant attente donnee" << endl;
	
	// Attendre
	wait(Wrapper_Ready_InPort.default_event());
	
	cout << "Wrapper_CoProc : apres attente donnee" << endl;
	
	// On r�cup�re la donn�e � envoyer sur le bus
	data = Wrapper_Data_OutPort.read();
	
	// Retrait de la requ�te
	Wrapper_Enable_OutPort.write(false);
	
	memcpy(ptrData, &data, len);
	
	cout << "Wrapper_CoProc : fin envoi d'une donn�e" << endl;
}


///////////////////////////////////////////////////////////////////////////////
//
//	busLT_slave_write
//  Le bus �crit des informations VERS le CoProc
//
///////////////////////////////////////////////////////////////////////////////
void wrapper_coProcessor_TLM::busLT_slave_write(sc_dt::uint64 add, unsigned char* ptrData, unsigned int len)
{
	unsigned int data ;
	
	cout << "Wrapper_CoProc : lecture d'une donn�e" << endl;
	
	memcpy(&data, ptrData, len);
	
	// On est en �criture
	Wrapper_RW_InPort.write(true);
	
	// On envoie l'adresse au CoProc
	Wrapper_Data_InPort.write(add);
	
	// On indique que la donn�e est pr�te
	Wrapper_Enable_OutPort.write(true);
	
	// Attendre
	wait(Wrapper_Ready_InPort.default_event());
	
	// Retrait de la requ�te
	Wrapper_Enable_OutPort.write(false);
	
	// Attente avant la deuxieme phase d'envoi
	wait(1);
	
	// On �crit la donn�e
	Wrapper_Data_InPort.write(data);
	
	// On indique que la donn�e est pr�te
	Wrapper_Enable_OutPort.write(true);
	
	// Attendre
	wait(Wrapper_Ready_InPort.default_event());
	
	// Retrait de la requ�te
	Wrapper_Enable_OutPort.write(false);
	
	cout << "Wrapper_CoProc : fin lecture d'une donn�e" << endl;
}


